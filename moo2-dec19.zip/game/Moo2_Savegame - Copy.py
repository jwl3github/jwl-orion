import os
import Moo2_LBX
import Data_TECH

# ==============================================================================
class Moo2_Savegame(object):
    """

    """
# ------------------------------------------------------------------------------
    def __init__(self, filename):
        """
        Loads the original MOO2 savegame
        """
        filesize    = os.path.getsize(filename)
        savefile    = open(filename, 'rb')
        self.file_data = savefile.read(filesize)
        savefile.close()
# ------------------------------------------------------------------------------
    def parse_game_settings(self):
        STRUCT_TABLE = [
            [ 'name',                            'A', 0x04, 23 ],
            [ 'end_of_turn_summary',             'B', 0x2E ],
            [ 'end_of_turn_wait',                'B', 0x2F ],
            [ 'random_events',                   'B', 0x30 ],
            [ 'enemy_moves',                     'B', 0x31 ],
            [ 'expanding_help',                  'B', 0x32 ],
            [ 'auto_select_ships',               'B', 0x33 ],
            [ 'animations',                      'B', 0x34 ],
            [ 'auto_select_colony',              'B', 0x35 ],
            [ 'show_relocation_lines',           'B', 0x36 ],
            [ 'show_gnn_report',                 'B', 0x37 ],
            [ 'auto_delete_trade_good_housing',  'B', 0x38 ],
            [ 'auto_save_game',                  'B', 0x39 ],
            [ 'show_only_serious_turn_summary',  'B', 0x3A ],
            [ 'ship_initiative',                 'B', 0x3B ],
        ]
        d_game_settings         = Moo2_LBX.read_struct(self.file_data, 0, STRUCT_TABLE)
        d_game_settings['name'] = d_game_settings['name'].lstrip(chr(0) + chr(1) + chr(2) + chr(3))
        return d_game_settings
# ------------------------------------------------------------------------------
    def parse_galaxy(self):
        STRUCT_TABLE = [
            [ 'size_factor',    'B', 0x31be4 ],
            [ 'width',          'S', 0x31be9 ],
            [ 'height',         'S', 0x31beb ],
            [ 'stardate',       'S', 0x29 ],
        ]
        d_galaxy = Moo2_LBX.read_struct(self.file_data, 0, STRUCT_TABLE)
        return d_galaxy
# ------------------------------------------------------------------------------
    def parse_hero_skills(self, d_hero_struct)
        COMMON_SKILL_MAP = {
                1:           [ 'assassin',          2   ],  # bit  0 = Assassin
                2:           [ 'assassin',          3   ],  # bit  1 = Assassin*
                4:           [ 'commando',          2   ],  # bit  2 = Commando
                8:           [ 'commando',          3   ],  # bit  3 = Commando*
                16:          [ 'diplomat',          10  ],  # bit  4 = Diplomat
                32:          [ 'diplomat',          15  ],  # bit  5 = Diplomat*
                64:          [ 'famous',            60  ],  # bit  6 = Famous
                128:         [ 'famous',            90  ],  # bit  7 = Famous*
                256:         [ 'megawealth',        10  ],  # bit  8 = Megawealth
                512:         [ 'megawealth',        15  ],  # bit  9 = Megawealth*
                1024:        [ 'operations',        2   ],  # bit 10 = Operations
                2048:        [ 'operations',        3   ],  # bit 11 = Operations*
                4096:        [ 'researcher',        5   ],  # bit 12 = Researcher
                8192:        [ 'researcher',        7.5 ],  # bit 13 = Researcher*
                16384:       [ 'spy_master',        2   ],  # bit 14 = Spy Master
                32768:       [ 'spy_master',        3   ],  # bit 15 = Spy Master*
                65536:       [ 'telepath',          2   ],  # bit 16 = Telepath
                131072:      [ 'telepath',          3   ],  # bit 17 = Telepath*
                262144:      [ 'trader',            10  ],  # bit 18 = Trader
                524288:      [ 'trader',            15  ],  # bit 19 = Trader*
        }
        SPECIAL_SKILLS_MAP = {
                1:           [ 'pollution_bonus',   10  ],  # bit  0 = Environmentalist
                2:           [ 'pollution_bonus',   15  ],  # bit  1 = Environmentalist*
                4:           [ 'farming_bonus',     10  ],  # bit  2 = Farming Leader
                8:           [ 'farming_bonus',     15  ],  # bit  3 = Farming Leader*
                16:          [ 'income_bonus',      10  ],  # bit  4 = Financial Leader
                32:          [ 'income_bonus',      15  ],  # bit  5 = Financial Leader*
                64:          [ 'instructor',        0.7 ],  # bit  6 = Instructor
                128:         [ 'instructor',        1.1 ],  # bit  7 = Instructor*
                256:         [ 'industry_bonus',    10  ],  # bit  8 = Labor Leader
                512:         [ 'industry_bonus',    15  ],  # bit  9 = Labor Leader*
                1024:        [ 'medicine',          10  ],  # bit 10 = Medicine
                2048:        [ 'medicine',          15  ],  # bit 11 = Medicine*
                4096:        [ 'research_bonus',    10  ],  # bit 12 = Science Leader
                8192:        [ 'research_bonus',    15  ],  # bit 13 = Science Leader*
                16384:       [ 'morale_bonus',      0   ],  # bit 14 = Spiritual Leader
                32768:       [ 'morale_bonus',      7.5 ],  # bit 15 = Spiritual Leader*
                65536:       [ 'tactics',           6   ],  # bit 16 = Tactics
                131072:      [ 'tactics',           9   ],  # bit 17 = Tactics*
        }

        d_skills = {}
        i_common_skills = hero_struct['common_skills']
        for k, v in COMMON_SKILL_MAP.iteritems():
            if i_common_skills & k:
                d_skills[v[0]] = v[1]

        if d_hero_struct['type'] == 1:
            i_special_skills = hero_struct['special_skills']
            for k, v in SPECIAL_SKILL_MAP.iteritems():
                if i_special_skills & k:
                    d_skills[v[0]] = v[1]

        return d_skills
# ------------------------------------------------------------------------------
    def parse_heroes(self):
        HEROES_DATA_OFFSET  = 0x19a9b
        HERO_RECORD_SIZE    = 0x3b         # = 59
        STRUCT_TABLE = [
            [ 'name':             'A', 15   ],
            [ 'title':            'A', 35   ],
            [ 'type':             'B', 0x23 ],
            [ 'experience':       'i', 0x24 ],
            [ 'tech1':            'B', 0x2e ],
            [ 'tech2':            'B', 0x2f ],
            [ 'tech3':            'B', 0x30 ],
            [ 'picture':          'B', 0x31 ],
            [ 'skill_value':      'S', 0x32 ],
            [ 'level':            'B', 0x34 ],
            [ 'location':         'S', 0x35 ],
            [ 'eta':              'B', 0x37 ],
            [ 'level_up':         'B', 0x38 ],
            [ 'status':           'B', 0x39 ],
            [ 'player':           'B', 0x3a ],
            [ 'common_skills':    'L', 0x26 ],
            [ 'special_skills':   'L', 0x2a ],
        ]
        d_heroes     = {}
        i_num_heroes = 67
        for i_hero_id in range(i_num_heroes):
            i_offset                      = HEROES_DATA_OFFSET + (HERO_RECORD_SIZE * i_hero_id)
            d_heroes[i_hero_id]           = Moo2_LBX.read_struct(self.file_data, i_offset, STRUCT_TABLE)
            d_heroes[i_hero_id]['id']     = i_hero_id
            d_heroes[i_hero_id]['skills'] = self.parse_hero_skills(d_heroes[i_hero_id])
        return d_heroes
# ------------------------------------------------------------------------------
    def parse_known_techs(self, offset):
        v_known_techs = []
        for i in range(203):               # original moo2 mas 203 usable technologies
            i_tech_status = Moo2_LBX.read_byte(self.file_data, offset + i)
            if i_tech_status == Data_TECH.TECH_KNOWN:
                v_known_techs.append(i + 1)
        return v_known_techs
# ------------------------------------------------------------------------------
    def add_npc_player(self, STRUCT_TABLE, d_players, i_player_id, s_emperor_name, s_race_name):
        ''' Manufacture a basic NPC player for special races like Antarans, etc. '''
        d_players[i_player_id] = {}
        o_player               = d_players[i_player_id]
        for v_field in STRUCT_TABLE:
            s_name, s_type_abbr, i_field_offset = v_field[0:2]
            if s_type_abbr == 'A' or s_type_abbr == 'a' or s_type_abbr = 'c':
                o_player[s_name] = ''
            else:
                o_player[s_name] = 0
        o_player['emperor_name']   = s_emperor_name
        o_player['race_name']      = s_race_name
# ------------------------------------------------------------------------------
    def parse_players(self):
        PLAYERS_DATA_OFFSET = 0x01aa0f
        PLAYER_RECORD_SIZE  = 3753
        STRUCT_TABLE = [
            [ 'emperor_name',              'A', 0,    15 ],
            [ 'race_name',                 'A', 0x14, 36 ],
            [ 'picture',                   'B', 0x24  ],
            [ 'color',                     'B', 0x25  ],
            [ 'personality',               'B', 0x26  ],
            [ 'objective',                 'B', 0x27  ],
            [ 'tax_rate',                  'B', 0x30  ],
            [ 'bc',                        'I', 0x31  ],
            [ 'total_frighters',           'S', 0x35  ],
            [ 'used_frighters',            'S', 0x37  ],
            [ 'total_command',             'S', 0x39  ],
            [ 'industry',                  'S', 0xA9  ],
            [ 'research',                  'S', 0xAB  ],
            [ 'food',                      'S', 0xAF  ],
            [ 'bc_income',                 's', 0xB1  ],
            [ 'research_progress',         'S', 0x1EA ],
            [ 'research_area',             'B', 0x320 ],
            [ 'research_item',             'B', 0x321 ],
            [ 'race_goverment',            'B', 0x89E ],
            [ 'race_population',           'b', 0x89F ],
            [ 'race_farming',              'b', 0x8A0 ],
            [ 'race_industry',             'b', 0x8A1 ],
            [ 'race_science',              'b', 0x8A2 ],
            [ 'race_money',                'b', 0x8A3 ],
            [ 'race_ship_defense',         'b', 0x8A4 ],
            [ 'race_ship_attack',          'b', 0x8A5 ],
            [ 'race_ground_combat',        'b', 0x8A6 ],
            [ 'race_spying',               'b', 0x8A7 ],
            [ 'race_low_g',                'B', 0x8A8 ],
            [ 'race_high_g',               'B', 0x8A9 ],
            [ 'race_aquatic',              'B', 0x8AA ],
            [ 'race_subterranean',         'B', 0x8AB ],
            [ 'race_large_home_world',     'B', 0x8AC ],
            [ 'race_rich_home_world',      'B', 0x8AD ],
              # where is poor_home_worlds?
            [ 'race_artifacts_home_world', 'B', 0x8AE ],
            [ 'race_cybernetic',           'B', 0x8AF ],
            [ 'race_lithovore',            'B', 0x8B0 ],
            [ 'race_repulsive',            'B', 0x8B1 ],
            [ 'race_charismatic',          'B', 0x8B2 ],
            [ 'race_uncreative',           'B', 0x8B3 ],
            [ 'race_creative',             'B', 0x8B4 ],
            [ 'race_tolerant',             'B', 0x8B5 ],
            [ 'race_fantastic_traders',    'B', 0x8B6 ],
            [ 'race_telepathic',           'B', 0x8B7 ],
            [ 'race_lucky',                'B', 0x8B8 ],
            [ 'race_omniscience',          'B', 0x8B9 ],
            [ 'race_stealthy_ships',       'B', 0x8BA ],
            [ 'race_trans_dimensional',    'B', 0x8BB ],
            [ 'race_warlord',              'B', 0x8BC ],
        ]
        d_players     = {}
        i_num_players = 8
        for i_player_id in range(i_num_players):
            i_offset                   = PLAYERS_DATA_OFFSET + (PLAYER_RECORD_SIZE * i_player_id)
            d_players[i_player_id]     = Moo2_LBX.read_struct(self.file_data, i_offset, STRUCT_TABLE)
            o_player                   = o_players[i_player_id]
            o_player['research_costs'] = 0
            o_player['known_techs']    = self.parse_known_techs(i_offset + 0x117)
            o_player['prototypes']     = []
            o_player['tributes']       = []

            for ii in range(6):
                i_offset2 = i_offset + 0x325 + (ii * 0x63)
                o_player['prototypes'].append(self.parse_ship_design(i_offset2))

            for ii in range(7):
                i_offset2 = i_offset + 0x649 + (ii)
                o_player['tributes'].append(Moo2_LBX.read_unsigned_byte(self.file_data, i_offset2))

        self.add_npc_player(STRUCT_TABLE, d_players, 8,  'Antareans',     'Antarean')
        self.add_npc_player(STRUCT_TABLE, d_players, 9,  'Orion',         'Loknar')
        self.add_npc_player(STRUCT_TABLE, d_players, 10, 'Space Amoeba',  'Amoeba')
        self.add_npc_player(STRUCT_TABLE, d_players, 11, 'Space Crystal', 'Crystal')
        self.add_npc_player(STRUCT_TABLE, d_players, 12, 'Space Dragon',  'Dragon')
        self.add_npc_player(STRUCT_TABLE, d_players, 13, 'Space Eel',     'Eel')
        self.add_npc_player(STRUCT_TABLE, d_players, 14, 'Space Hydra',   'Hydra')
        return players
# ------------------------------------------------------------------------------
    def parse_stars(self):
        #       http://www.spheriumnorth.com/orion-forum/nfphpbb/viewtopic.php?p=149
        SOLAR_SYSTEMS_COUNT_OFFSET  = 0x17ad1
        SOLAR_SYSTEMS_DATA_OFFSET   = 0x17ad3
        SOLAR_SYSTEM_RECORD_SIZE    = 0x71
        STRUCT_TABLE = [
                [ 'name',                      'A',  0,   15 ],
                [ 'x',                         'S',  0x0f ],
                [ 'y',                         'S',  0x11 ],
                [ 'size',                      'B',  0x13 ],
                [ 'owner',                     'B',  0x14 ],  # primary owner
                [ 'pict_type',                 'B',  0x15 ],
                [ 'class',                     'B',  0x16 ],
                [ 'last_planet_selected',      'B',  0x17, 8 ],
                [ 'special',                   'B',  0x28 ],
                [ 'wormhole',                  'B',  0x29 ],
                [ 'blockaded_players',         'B',  0x2a ],
                [ 'blockaded_by_bitmask',      'B',  0x2b, 8 ],
                [ 'visited',                   'B',  0x33 ],  # bitmask as booleans for each player
                [ 'just_visited_bitmask',      'B',  0x34 ],  # players bitmask to track first visit of this star -> user should get report
                [ 'ignore_colony_ship_bitmask' 'B',  0x35 ],  # players bitmask to track if player chose to not use a colony ship, cleared on every new colony ship here?
                [ 'ignore_combat_bitmask',     'B',  0x36 ],  # players bitmask to track if player chose to ignore combat ships = perform blockade only do not fight here?
                [ 'colonize_player',           'B',  0x37 ],  # 0..7 or -1
                [ 'colonies_bitmask',          'B',  0x38 ],  # has colony / players bitmask / redundant info?
                [ 'interdictors_bitmask',      'B',  0x39 ],  # has warp interdictor / players bitmask
                [ 'next_wfi_in_list',          'B',  0x3a ],  # bookeeping ???
                [ 'tachyon_com_bitmask',       'B',  0x3b ],  # has tachyon communicator / players bitmask
                [ 'subspace_com_bitmask',      'B',  0x3c ],  # has subspace communicator / players bitmask
                [ 'stargates_bitmask',         'B',  0x3d ],  # has stargate / players bitmask
                [ 'jumpgates_bitmask',         'B',  0x3e ],  # has jumpgate / players bitmask
                [ 'artemis_bitmask',           'B',  0x3f ],  # has artemis net players bitmask
                [ 'portals_bitmask',           'B',  0x40 ],  # has dimension portal / players bitmask
                [ 'stagepoint_bitmask',        'B',  0x41 ],  # bitvector tells whether star is stagepoint for each AI
                [ 'players_officers',          'B',  0x42, 8 ],
                [ 'objects',                   'S',  0x4a, 5 ],
                [ 'surrender_to',              'B',  0x67, 8 ],
                [ 'is_in_nebula',              'B',  0x6f ],
        ]

"""
                'black_hole_blocks': [ ],
                '0x1f': ord(self.file_data[0x1f]),
                '0x20': ord(self.file_data[0x20]),
                '0x21': ord(self.file_data[0x21]),
                '0x22': ord(self.file_data[0x22]),
                '0x23': ord(self.file_data[0x23]),
                '0x24': ord(self.file_data[0x24]),
                '0x25': ord(self.file_data[0x25]),
                '0x26': ord(self.file_data[0x26]),
                '0x27': ord(self.file_data[0x27]),
                '0x2a': ord(self.file_data[0x2a]), # blockaded? ( 0 | 1 )
                '0x2b': ord(self.file_data[0x2b]),
                '0x2c': ord(self.file_data[0x2c]),
                '0x2d': ord(self.file_data[0x2d]),
                '0x2e': ord(self.file_data[0x2e]),
                '0x2f': ord(self.file_data[0x2f]),
                '0x30': ord(self.file_data[0x30]),
                '0x31': ord(self.file_data[0x31]),
                '0x32': ord(self.file_data[0x32]),
                '0x34': ord(self.file_data[0x34]),
                '0x35': ord(self.file_data[0x35]),
                '0x36': ord(self.file_data[0x36]),
                '0x37': ord(self.file_data[0x37]),
                '0x38': ord(self.file_data[0x38]),
                '0x3a': ord(self.file_data[0x3a]),
                '0x3b': ord(self.file_data[0x3b]),
                '0x3c': ord(self.file_data[0x3c]),
                '0x3d': ord(self.file_data[0x3d]),
                '0x3e': ord(self.file_data[0x3e]), # jumpgate players bitmask
                '0x3f': ord(self.file_data[0x3f]), # artemist_net players bitmask
                '0x40': ord(self.file_data[0x40]), # dimensional portal players bitmask
                '0x41': ord(self.file_data[0x41]), # is_stagepoint bitvector tells whether star is stagepoint for each AI
                '0x42': ord(self.file_data[0x42]), # officer_id for player #0
                '0x43': ord(self.file_data[0x43]), # officer_id for player #1
                '0x44': ord(self.file_data[0x44]), # officer_id for player #2
                '0x45': ord(self.file_data[0x45]), # officer_id for player #3
                '0x46': ord(self.file_data[0x46]), # officer_id for player #4
                '0x47': ord(self.file_data[0x47]), # officer_id for player #5
                '0x48': ord(self.file_data[0x48]), # officer_id for player #6
                '0x49': ord(self.file_data[0x49]), # officer_id for player #7
    #??? Relocation star id (0-7 player #, not sure about size of array. )
                '0x54': ord(self.file_data[0x54]),
                '0x55': ord(self.file_data[0x55]),
                '0x56': ord(self.file_data[0x56]),
                '0x57': ord(self.file_data[0x57]),
                '0x58': ord(self.file_data[0x58]),
                '0x59': ord(self.file_data[0x59]),
                '0x5a': ord(self.file_data[0x5a]),
                '0x5b': ord(self.file_data[0x5b]),
                '0x5c': ord(self.file_data[0x5c]),
                '0x5d': ord(self.file_data[0x5d]),
                '0x5e': ord(self.file_data[0x5e]),
                '0x5f': ord(self.file_data[0x5f]),
                '0x60': ord(self.file_data[0x60]),
                '0x61': ord(self.file_data[0x61]),
                '0x62': ord(self.file_data[0x62]),
                '0x63': ord(self.file_data[0x63]),
    # unknown:
                '0x64': ord(self.file_data[0x64]),     # not used? always = 255 ?
                '0x65': ord(self.file_data[0x65]),     # not used? always = 255 ?
                '0x66': ord(self.file_data[0x66]),     # not used? always = 0 ?
                '0x67': ord(self.file_data[0x67]),     # surrender to #0 normally -1, else player to give colonies to
                '0x68': ord(self.file_data[0x68]),     # surrender to #1 normally -1, else player to give colonies to
                '0x69': ord(self.file_data[0x69]),     # surrender to #2 normally -1, else player to give colonies to
                '0x6a': ord(self.file_data[0x6a]),     # surrender to #3 normally -1, else player to give colonies to
                '0x6b': ord(self.file_data[0x6b]),     # surrender to #4 normally -1, else player to give colonies to
                '0x6c': ord(self.file_data[0x6c]),     # surrender to #5 normally -1, else player to give colonies to
                '0x6d': ord(self.file_data[0x6d]),     # surrender to #6 normally -1, else player to give colonies to
                '0x6e': ord(self.file_data[0x6e]),     # surrender to #7 normally -1, else player to give colonies to
                '0x6f': ord(self.file_data[0x6f]),     # in nebula
                '0x70': ord(self.file_data[0x70])      # artifacts_gave_app
"""
        d_stars     = {}
        i_num_stars = Moo2_LBX.read_unsigned_byte(self.file_data, SOLAR_SYSTEMS_COUNT_OFFSET)
        for i_star_id in range(i_num_stars):
            i_offset                    = SOLAR_SYSTEMS_DATA_OFFSET + (SOLAR_SYSTEM_RECORD_SIZE * i_star_id)
            d_stars[i_star_id]          = Moo2_LBX.read_struct(self.file_data, i_offset, STRUCT_TABLE)
            o_star                      = d_stars[i_star_id]
            o_star['blockaded_players'] = bitmask_to_player_id_list(o_star['blockaded_players'])
            o_star['is_in_nebula']      = (o_star['is_in_nebula'] == 1)
        return v_stars
# ------------------------------------------------------------------------------
    def parse_planets(self, d_stars):
        PLANETS_COUNT_OFFSET    = 0x162e7
        PLANETS_DATA_OFFSET     = 0x162e9
        PLANET_RECORD_SIZE      = 0x11
        STRUCT_TABLE = [
                [ 'colony_id',        'S', 0x00 ], # 0xffff = no colony here
                [ 'star',             'B', 0x02 ],
                [ 'position',         'B', 0x03 ],
                [ 'type',             'B', 0x04 ],
                [ 'size',             'B', 0x05 ],
                [ 'gravity',          'B', 0x06 ],
                [ 'group',            'B', 0x07 ],   # not used ?
                [ 'terrain',          'B', 0x08 ],
                [ 'picture',          'B', 0x09 ],   # Background image on colony screen (0-5=image in planets.lbx)
                [ 'minerals',         'B', 0x0a ],
                [ 'foodbase',         'B', 0x0b ],
                [ 'terraformations',  'B', 0x0c ],
                [ 'max_farms',        'B', 0x0d ],   # unknown (Initial value is based on Planet Size but changes if colonized), 2=tiny, 4=small, 5=med, 7=large, A=huge
                [ 'max_population',   'B', 0x0e ],
                [ 'special',          'B', 0x0f ],
                [ 'flags',            'B', 0x10 ],   # (bit 2 = Soil Enrichment)
        ]
        d_planets     = {}
        i_num_planets = Moo2_LBX.read_unsigned_short(self.file_data, PLANETS_COUNT_OFFSET)
        for i_planet_id in range(i_num_planets):
            i_offset               = PLANETS_DATA_OFFSET + (PLANET_RECORD_SIZE * i_planet_id)
            d_planets[i_planet_id] = Moo2_LBX.read_struct(self.file_data, i_offset, STRUCT_TABLE)
        return d_planets
# ------------------------------------------------------------------------------
    def parse_colony_pop(data, population):
        d_colony_pop = {0x02: [], 0x03: [], 0x82: []}
        for i in range(population):
            i_offset = 0x0C + (4 * i)
            i_type = (Moo2_LBX.read_char(data, i_offset) & 0x80) + (Moo2_LBX.read_char(data, i_offset + 1) & 3)
            d_colony_pop[i_type].append({
                'a':     Moo2_LBX.read_char(data, i_offset),
                'b':     Moo2_LBX.read_char(data, i_offset + 1),
                'c':     Moo2_LBX.read_char(data, i_offset + 2),
                'd':     Moo2_LBX.read_char(data, i_offset + 3),
                'r1':    (Moo2_LBX.read_char(data, i_offset) & 0x70) >> 4,
                'race':  (Moo2_LBX.read_char(data, i_offset) & 0x07)
            })
        return d_colony_pop
# ------------------------------------------------------------------------------
    def parse_colonies(self):
        COLONIES_DATA_OFFSET = 0x0025d
        COLONY_RECORD_SIZE   = 361
        STRUCT_TABLE = [
                [ 'owner_id',               'c', 0x000 ],
                [ 'allocated_to',           'c', 0x001 ],
                [ 'set_planet_id',          'c', 0x002 ],
                [ 'officer_id',             'S', 0x004 ],
                [ 'is_outpost',             'c', 0x006 ],
                [ 'morale',                 'c', 0x007 ],
                [ 'pollution',              'S', 0x008 ],
                [ 'population',             'c', 0x00a ],
                [ 'assignment',             'c', 0x00b ],
                [ 'pop_raised',             'S', 0x0B4, 10 ],   # 8 races, andriods, natives
                [ 'pop_grow',               'S', 0x0C8, 10 ],   # 8 races, andriods, natives
                [ 'num_turns_existed',      'B', 0x0DC ], # bookeeping
                [ 'food2_per_farmer',       'B', 0x0DD ], # Food per farmer in half-units of food
                [ 'industry_per_worker',    'B', 0x0DE ],
                [ 'research_per_scientist', 'B', 0x0DF ],
                [ 'max_farms',              'B', 0x0E0 ],
                [ 'max_population',         'B', 0x0E1 ],
                [ 'climate',                'B', 0x0E2 ],
                [ 'ground_strength',        'S', 0x0E3 ], # calculated for ai
                [ 'space_strength',         'S', 0x0E5 ], # calculated for ai
                [ 'food',                   'S', 0x0E7 ], # total food = food - population
                [ 'industry',               'S', 0x0E9 ],
                [ 'research',               'S', 0x0EB ],
                [ 'num_marines',            'c', 0x130 ],
                [ 'num_armors',             'c', 0x132 ],
        ]
        d_colonies     = {}
        i_num_colonies = Moo2_LBX.read_unsigned_short(self.file_data, 0x25b)
        for i_colony_id in range(i_num_colonies):
            i_offset                 = COLONIES_DATA_OFFSET + (COLONY_RECORD_SIZE * i_colony_id)
            d_colonies[i_colony_id]  = Moo2_LBX.read_struct(self.file_data, i_offset, STRUCT_TABLE)
            o_colony                 = d_colonies[i_colony_id]
            o_colony['morale']      *= 5 # Morale value is stored as divided by 5
            o_colony['colonists']    = parse_colony_pop(data, colony['population'])
            o_colony['build_queue']  = []
            o_colony['building_ids'] = []

            for i_queue_id in range(0, 7):
                i_production_id    = Moo2_LBX.read_byte(data, 0x115 + i_queue_id*2)
                i_production_flags = Moo2_LBX.read_byte(data, 0x115 + i_queue_id*2 + 1)
                if i_production_id < 0xFF:
                    o_colony['build_queue'].append({'production_id': i_production_id, 'flags': i_production_flags})

            for i_building_id in range(1, 49):
                i_offset = 0x136 + i_building_id
                if Moo2_LBX.read_byte(data, i_offset) != 0:
                    o_colony['building_ids'].append(i_building_id)
        return d_colonies
# ------------------------------------------------------------------------------
    def parse_ship_design(self, offset):
        WPN_STRUCT_TABLE = [
                [ 'weapon',        'B',  0x00 ],
                [ 'count',         'B',  0x02 ],
                [ 'current_count', 'B',  0x03 ],
                [ 'arc',           'B',  0x04 ],
                [ 'beam_mods',     'B',  0x05 ],
                [ 'missile_mods',  'B',  0x06 ],
                [ 'ammo',          'B',  0x07 ],
        ]
        STRUCT_TABLE = [
                [ 'name':            'A', 0x00,  16 ],
                [ 'size':            'B', 0x10 ],
                [ 'type':            'B', 0x11 ],
                [ 'shield':          'B', 0x12 ],
                [ 'drive':           'B', 0x13 ],
                [ 'speed':           'B', 0x14 ],
                [ 'computer':        'B', 0x15 ],
                [ 'armor':           'B', 0x16 ],
                [ 'special_devices': 'B', 0x17,  6 ], # char  special_device_flags[(MAX_SPECIALS+7)/8];
                [ 'picture':         'B', 0x5C ],
                [ 'builder':         'B', 0x5D ],        # or previous owner?
                [ 'cost':            'S', 0x5E ],
                [ 'combat_speed':    'B', 0x60 ],
                [ 'build_date':      'S', 0x61 ],
        ]
        v_weapons = []
        MAX_WEAPONS = 8
        for i in range(MAX_WEAPONS):
            i_offset2 = i_offset + 0x1C + (8 * i)
            d_weapon  = Moo2_LBX.read_struct(data, i_offset2, WPN_STRUCT_TABLE)
            if d_weapon['weapon'] > 0:
                v_weapons.append(d_weapon)

        d_design                    = Moo2_LBX.read_struct(data, i_offset2, STRUCT_TABLE)
        d_design['weapons']         = v_weapons
        d_design['special_devices'] = bitarray(bytearray(d_design['special_devices']))
        return d_design
# ------------------------------------------------------------------------------
    def parse_ships(self):
        SAVE_SHIP_COUNT_OFFSET = 0x21f56
        SAVE_SHIPS_OFFSET      = 0x21f58
        SAVE_SHIP_RECORD_SIZE  = 0x81        # = 129
        STRUCT_TABLE = [
                [ 'owner',                  'B', 0x63 ],
                [ 'status',                 'B', 0x64 ],
                [ 'destination',            'S', 0x65 ],
                [ 'x',                      'S', 0x67 ],
                [ 'y',                      'S', 0x69 ],
                [ 'group_has_navigator',    'B', 0x6B ],
                [ 'travelling_speed',       'B', 0x6C ],     # possibly less than ftl_type
                [ 'turns_left',             'B', 0x6D ],     # until arrival
                [ 'shield_damage_percent',  'B', 0x6E ],
                [ 'drive_damage_percent',   'B', 0x6F ],
                [ 'computer_damage',        'B', 0x70 ],
                [ 'crew_quality',           'B', 0x71 ],
                [ 'crew_experience',        'S', 0x72 ],
                [ 'officer_id',             'S', 0x74 ],
                [ 'special_device_damage',  'B', 0x76,   6 ], # bit flag array
                [ 'armor_damage',           'S', 0x7B ],
                [ 'structural_damage',      'S', 0x7D ],
                [ 'mission',                'B', 0x7F ],              # used for AI
                [ 'just_built',             'B', 0x80 ],
        ]
        d_ships     = {}
        i_num_ships = Moo2_LBX.read_unsigned_short(self.file_data, SAVE_SHIP_COUNT_OFFSET)
        for i_ship_id in range(i_num_ships):
            i_offset         = SAVE_SHIPS_OFFSET + (SAVE_SHIP_RECORD_SIZE * i_ship_id)
            d_ships[ship_id] = Moo2_LBX.read_struct(self.file_data, i_offset, STRUCT_TABLE)
            o_ship['destination'] %= 500
            o_ship['design']       = self.parse_ship_design(i_offset)
            o_ship['name']         = o_ship['design']['name']
        return d_ships
# ------------------------------------------------------------------------------
    def init_stars(self):
        self.stars_by_coords = {}
        for i_star_id in self.stars:
            o_star = self.stars[i_star_id]
            k = "%i:%i" % (star['x'], star['y'])
            self.stars_by_coords[k] = o_star
            i_num = 0
            for i_object in star['objects']:
                if i_object != 0xffff:
                    i_num += 1
                    self.planets[i_object]['num'] = i_num
# ------------------------------------------------------------------------------
    def init_heroes(self):
        self.players_heroes = {}
        for o_hero in self.heroes:
            i_player_id = o_hero['player']
            if i_player_id != 0xFF:
                if not self.players_heroes.has_key(i_player_id):
                    self.players_heroes[i_player_id] = {}
                self.players_heroes[i_player_id][o_hero['id']] = o_hero
