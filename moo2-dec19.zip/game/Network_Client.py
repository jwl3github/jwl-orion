import socket
import pickle
import Network_GameSocket
import re
import time

class Network_Client(object):

    def __init__(self):
        self.socket = Network_GameSocket.Network_GameSocket(socket.socket(socket.AF_INET, socket.SOCK_STREAM))
        self.socket.settimeout(1)

    def connect(self, host, port, buffer_size = 4096):
        self.socket.buffer_size = buffer_size
        self.host = host
        self.port = port
        self.socket.connect((host, port))

    def disconnect(self):
        self.socket.close()

    def recv(self):
        return self.socket.recv()

    def send(self, action, params = None):
        print("\n* ACTION: %s\nPARAMS: %s\n" % (action, str(params)))
        self.socket.send({'action': action, 'params': params})

    def login(self, player_id):
        self.player_id = player_id
        self.send("LOGIN", {'player_id': player_id})

    def logout(self):
        self.send("LOGOUT")

    def get_server_name(self):
        self.send("GET_NAME")
        return self.recv()

    def fetch_update_data(self):
        self.send("FETCH_UPDATE_DATA")
        update_data = self.recv()
        if not update_data:
            print("! ERROR: Network_Client::fetch_update_data() ... no data???")
            return False
        player = self.game_data['players'][self.player_id]
        player.unserialize(update_data)
        print ("fetch_update_data DONE.")
        player.print_debug()
        return True

    def fetch_game_data(self):
        #time.sleep(0.01)   # Time in seconds; can be floating point.
        self.send("FETCH_GAME_DATA")
        self.game_data = self.recv()
        if not self.game_data:
            print("! ERROR: Network_Client::fetch_game_data() ... no data???")
            return False
        return True

    def game_data(self):
        return self.game_data

    def rules(self):
        return self.game_data['rules']

    def get_galaxy(self):
        return self.game_data['galaxy']

    def get_stardate(self):
        return self.game_data['galaxy']['stardate']

    def list_stars(self):
        return self.game_data['stars']

    def get_star(self, star_id):
        return self.game_data['stars'][star_id]

    def list_stars_by_coords(self):
        return self.game_data['stars_by_coords']

    def list_planets(self):
        return self.game_data['planets']

    def get_planet(self, planet_id):
        return self.game_data['planets'][planet_id]

    def list_colonies(self):
        return self.game_data['colonies']

    def get_colony(self, colony_id):
        return self.game_data['colonies'][colony_id]

    def list_ship_ids(self):
        """returns all ships as a list of ship_id's (old method)"""
        return self.game_data['ships']

    def list_ships(self,player_id=-1):
        """
        returns ships of one player as a list of starship objects
        """
        ships = []
        for ship_id in self.game_data['ships']:
            ship        = self.game_data['ships'][ship_id]
            ship_player = self.game_data['players'][ship.owner_id]
            if ship.has_no_image() and hasattr(player, 'color'):
                color = player.get_color()
                ship.determine_image_keys(color)
            if ship.owner_id == player_id and ship.exists():
                ships.append(ship)
        return ships

    def list_prototypes(self):
        return self.game_data['prototypes']

    def list_officers(self):
        return self.game_data['officers']

    def list_colony_leaders(self):
        return self.game_data['colony_leaders']

    def list_players(self):
        return self.game_data['players']

    def get_player(self, player_id):
        return self.game_data['players'][player_id]

    def get_me(self):
        return self.game_data['me']

    def next_turn(self):
        print("Network_Client::next_turn()")
        self.send("NEXT_TURN")
        response = ''
# JWL: Need a timeout
        while response != 'NEXT_TURN_ACK':
            response = self.recv()
            print 'wait_for_next_turn: response = '
            print response
        return response == 'NEXT_TURN_ACK'

    def set_research(self, tech_id):
#print("Network_Client::set_research() ... tech_id = %i" % tech_id)
        self.send("SET_RESEARCH", {'tech_id': tech_id})
        #JWL# return self.fetch_game_data()
        return self.fetch_update_data()

    def get_server_status(self):
        self.send("GET_SERVER_STATUS")
        return self.recv()

    def ping(self):
        tm1 = time.time()
        self.send("PING")
        ping_response = self.recv()
        tm2 = time.time()
        ping_time = round(tm2 - tm1, 2)
        if ping_response == "PONG":
            print("PING: %ss" % (ping_time))
        else:
            print("PING: WRONG RESPONSE '%s' returned in %ss" % (ping_response, ping_time))


    def set_colony_build_queue(self, colony_id, build_queue):
        """ Sends the new build queue for given player's colony """
        self.send("SET_BUILD_QUEUE", {'colony_id': colony_id, 'build_queue': build_queue})
        #JWL# return self.fetch_game_data()
        return self.fetch_update_data()


Client = Network_Client()
