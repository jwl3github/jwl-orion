class Game_Object(object):

    def __init__(self, i_id):
        self.i_id   = -1
        self.s_name = ''
