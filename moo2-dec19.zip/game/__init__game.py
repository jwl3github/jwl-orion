import pygame
from pygame.locals import *
import copy

import lbx

import networking
import gui
import gui_client

GUI = gui_client.GuiClient()
